"""Score the checkpoints of the new-skill models and pick one per model.

For each checkpoint: the start test (start_test.scores) and the grasp
fit (box_fit_test.fit, mean |err| at 0.5 s before the grasp) on the
new-skill demos and on dataset B. Writes a Markdown report.

Rules:
  1. leaves home: gripper opens >= 0.9 at "old run, 1.6 s" and roll
     turn >= 15 deg at "old run, start frame" (the stalled DAgger
     model: 6.5 deg; the old model: 32 deg);
  2. old skill kept: B fit error <= old model B fit error + 1 deg;
  3. of the rest: the lowest new-skill fit error.

  python outputs/portfolio/parcel_task/pick_checkpoint.py \
    --out outputs/train/skill_report.md
"""

import argparse
import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).parent))
import box_fit_test as bf  # noqa: E402
import offline_eval as oe  # noqa: E402
import offline_eval_b as ob  # noqa: E402
import start_test as stt  # noqa: E402

BOX = ("parcel-skill-boxstack-cut", 1)
FE = ("rollout_dagger_far_edge_pull", 1)
B = ("parcel-sort-b", 4)
# model: (SPECS name, new-skill set, candidate SPECS names with :step)
GROUPS = {
    "box + far edge (smolvla_b_fb)": ("smolvla_b_fb", BOX, ["smolvla_b_box"]),
    "far edge only (smolvla_b_fe15)": ("smolvla_b_fe15", FE,
                                       ["smolvla_b_fe"]),
}


def steps(spec):
    run, _ = ob.SPECS[spec]
    ck = ob.TRAIN / run / "checkpoints"
    return sorted(p.name for p in ck.glob("[0-9]*"))


def score(spec, step, new_set):
    run, last = ob.SPECS[spec]
    oe.MODELS[spec] = ob.TRAIN / run
    m = oe.Model(spec, step or last)
    st = stt.scores(m)
    fit = {}
    for key, (ds_name, every) in (("new", new_set), ("b", B)):
        _, res = bf.fit(m, ds_name, every)
        fit[key] = float(np.abs(res[15]).mean())
    del m
    torch.cuda.empty_cache()
    return {"roll": st["old run, start frame"][0],
            "grip": st["old run, 1.6 s"][1],
            "reach": st["B starts (25 eps)"][2],
            "new": fit["new"], "b": fit["b"]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path,
                    default=ob.TRAIN / "skill_report.md")
    args = ap.parse_args()
    lines = ["# New-skill checkpoints: offline scores", "",
             "Roll: start test, old-run start frame (pass >= 15, old "
             "model 32). Grip: gripper opens at 1.6 s. Fit: mean grasp "
             "pose error 0.5 s before the grasp, deg (lower is better).",
             ""]
    old = None
    for title, (spec, new_set, extra) in GROUPS.items():
        cands = [f"{spec}:{s}" for s in steps(spec)] + extra + ["smolvla_b"]
        rows = {}
        for c in cands:
            name, _, step = c.partition(":")
            print(f"scoring {c}", flush=True)
            if name == "smolvla_b" and old is not None:
                rows[c] = dict(old)
                rows[c]["new"] = score(name, step, new_set)["new"]
                continue
            rows[c] = score(name, step, new_set)
            if name == "smolvla_b":
                old = rows[c]
        b_max = rows["smolvla_b"]["b"] + 1.0
        ok = [c for c in cands if c != "smolvla_b"
              and rows[c]["grip"] >= 0.9 and rows[c]["roll"] >= 15
              and rows[c]["b"] <= b_max]
        pick = min(ok, key=lambda c: rows[c]["new"]) if ok else None
        lines += [f"## {title}", "",
                  "| Checkpoint | Roll | Grip | New-skill fit | B fit "
                  "| Passes rules 1-2 |",
                  "|---|---|---|---|---|---|"]
        for c in cands:
            r = rows[c]
            lines.append(f"| `{c}` | {r['roll']:.1f} | {r['grip']:.2f} "
                         f"| {r['new']:.1f} | {r['b']:.1f} "
                         f"| {'yes' if c in ok else 'no'} |")
        lines += ["", f"Pick: `{pick}`" if pick else
                  "Pick: none passes the rules", ""]
    args.out.write_text("\n".join(lines) + "\n")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
